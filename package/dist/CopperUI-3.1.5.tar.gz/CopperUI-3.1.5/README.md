# Project CopperHead
CopperUI is a python package, which is designed to fix my personal grievances. it changes syntax to be easier to read, and makes TUI applications easier to write.

<h1>Why Copperhead?</h1>
Copperhead is a python package made for making beautiful applications and tools in the command line. 

<h1>how does it work?</h1>
Copperhead uses shortcuts to change syntax, but comes with extra packages that I find absolutley necessary for most projects.

<h1>Features:</h1>

copperhead makes it easier to make TUI applications, starting with personalization. **all** textual functions include both a color, and text option. this lets you change the color to match everything. 

<h1>how to install?</h1>

``pip install CopperUI``
